package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.view.Gravity.CENTER;

public class Home extends AppCompatActivity {
    TextView location, covid, past_locations,virus;
    LinearLayout ln;
    BottomNavigationView home_nav;
    private static final int Request_user_location_code = 99;
    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        Paper.init(this);

        ActionBar toolbar = getSupportActionBar();
        String name;
        toolbar.setTitle("Welcome Back  " + Paper.book().read(utilities.username) + " !");
        toolbar.setIcon(R.mipmap.ic_launcher);
        virus = findViewById(R.id.virus);
        ln = findViewById(R.id.layout);
        final tip rows = new tip(this);

        final int[] colors = {R.drawable.color_green, R.drawable.color_yellow, R.drawable.color,R.drawable.color_important};

        /** Contact with someone with Covid-19 ***/
        /* if(Covid-19)
        *  then create thing        *
        * */
        if(!isNetworkAvailable()){
            Intent no_internet = new Intent(this,no_internet.class);
            startActivity(no_internet);
            CustomIntent.customType(this,"rotateout-to-rotatein");
        }
        else {
            if(Paper.book().read(utilities.virus).toString().equals("0")) {
                /*** OKHTTP ********/
                OkHttpClient client = new OkHttpClient();


                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/InContact.php").newBuilder();
                urlBuilder.addQueryParameter("user", Paper.book().read(utilities.id).toString() );
                String url = urlBuilder.build().toString();
                final Request request = new Request.Builder()
                        .url(url)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                                if(response.isSuccessful()){
                                    final String responseData = response.body().string();
                                     Home.this.runOnUiThread(new Runnable() {
                                         @Override
                                         public void run() {
                                             try {
                                                 JSONArray all = new JSONArray(responseData);

                                                 if(all.length() == 0){

                                                 }
                                                 else {

                                                     JSONObject obj = all.getJSONObject(0);
                                                     String lat = obj.getString("LOCATION_LATITUDE");
                                                     String lon = obj.getString("LOCATION_LONGITUDE");
                                                     final String date = obj.getString("LOCATION_DATE");
                                                     final LatLng coordinate = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));
                                                     TextView covid = new TextView(Home.this);
                                                     covid = rows.add("You have recently been in contact with Someone who has COVID-19 ... click here for more details",
                                                             getResources().getDrawable(colors[3]), getResources().getDrawable(R.drawable.ic_alert));

                                                     covid.setOnClickListener(new View.OnClickListener() {
                                                         @Override
                                                         public void onClick(View v) {
                                                            openDialog(date,getAddress(coordinate.latitude,coordinate.longitude));
                                                         }
                                                     });
                                                     virus.setVisibility(View.VISIBLE);
                                                     virus.setPadding(10, 15, 15, 15);
                                                     virus.setText("You have recently been in contact with Someone who has COVID-19 ... click here for more details");
                                                     virus.setTextSize(16);
                                                     virus.setBackground(getResources().getDrawable(colors[3]));
                                                     virus.setCompoundDrawablesWithIntrinsicBounds(getResources().getDrawable(R.drawable.ic_alert),null,null,null);
                                                     virus.setTextColor(Color.WHITE);
                                                     virus.setGravity(CENTER);
                                                     virus.setOnClickListener(new View.OnClickListener() {
                                                         @Override
                                                         public void onClick(View v) {
                                                             openDialog(date,getAddress(coordinate.latitude,coordinate.longitude));
                                                         }
                                                     });

                                                 }

                                             } catch (JSONException e) {
                                                 e.printStackTrace();

                                             }
                                         }
                                     });
                                }
                                else{
                                    Toast.makeText(Home.this,"Oops !, Something went wrong",Toast.LENGTH_LONG).show();
                                }
                    }
                });


            }

            TextView location = new TextView(this);
            location = rows.add(Paper.book().read(utilities.username) + "'s current location : " + getCurrentLocation(),
                    getResources().getDrawable(colors[2])
                    , getResources().getDrawable(R.drawable.ic_outline_location_on_24));
            ln.addView(location);

            TextView unwell = new TextView(this);
            unwell = rows.add("Feeling unwell ? , Check out our self check", getResources().getDrawable(colors[0]), getResources().getDrawable(R.drawable.ic_outline_local_hospital_24));
            unwell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Home.this, Self_check.class);
                    CustomIntent.customType(Home.this, "fadein-to-fadeout");
                    startActivity(i);
                }
            });
            ln.addView(unwell);

            ArrayList<TextView> app_tips = new ArrayList<>();
            ArrayList<String> tips = new ArrayList<>();
            tips.add("Clean your hands often. Use soap and water, or an alcohol-based hand rub.");
            tips.add("Maintain a safe distance from anyone who is coughing or sneezing.");
            tips.add("Don’t touch your eyes, nose or mouth.");
            tips.add("Cover your nose and mouth with your bent elbow or a tissue when you cough or sneeze.");
            tips.add("Stay home if you feel unwell.");
            tips.add("If you have a fever, cough and difficulty breathing, seek medical attention. Call in advance");
            tips.add("Follow the directions of your local health authority");
            tips.add("Maintain Social Distancing where possible");
            tips.add("Limit Movement to only essentials");
            tips.add("Avoid Crowded areas");
            TextView profile = rows.add("Want to See your Profile ?", getResources().getDrawable(R.drawable.smart), getResources().getDrawable(R.drawable.ic_smartphone));
            TextView stats = rows.add("See the latest COVID-19 statistics", getResources().getDrawable(R.drawable.smart), getResources().getDrawable(R.drawable.ic_smartphone));
            TextView prev = rows.add("Want to see places you've recently visited ?", getResources().getDrawable(R.drawable.smart), getResources().getDrawable(R.drawable.ic_smartphone));
            /*** Onclick Listenners ***/
            prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Home.this,Previous_locations.class);
                    startActivity(i);
                }
            });
            stats.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Home.this,Map_summary.class);
                    startActivity(i);
                }
            });
            profile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(Home.this,Profile.class);
                    startActivity(i);
                }
            });

            /************************/
            ln.addView(profile);
            ln.addView(stats);
            ln.addView(prev);


            Random rand = new Random();
            for (int n = 0; n < 3; n++) {
                int r = rand.nextInt(3);
                int i = rand.nextInt(tips.size());
                TextView t = rows.add(tips.get(i), getResources().getDrawable(R.drawable.card_shape), getResources().getDrawable(R.drawable.ic_idea));
                ln.addView(t);
            }
        }
        TextView blank = new TextView(this);
        blank.setHeight(56);
        ln.addView(blank);

        /*** Setting up the Nav Bar ****/
        home_nav = findViewById(R.id.navigation);
        home_nav.setSelectedItemId(R.id.home);

        home_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        return true;
                    case R.id.search:
                        startActivity(new Intent(Home.this, Search.class));
                        CustomIntent.customType(Home.this, "fadein-to-fadeout");
                        return true;
                    case R.id.myLocations:
                        startActivity(new Intent(Home.this, myLocation.class));
                        CustomIntent.customType(Home.this, "fadein-to-fadeout");
                        return true;
                    case R.id.self_check:
                        startActivity(new Intent(Home.this, Self_check.class));
                        CustomIntent.customType(Home.this, "fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        activity = new Intent(Home.this, Map_graph.class);
                        startActivity(activity);
                        CustomIntent.customType(Home.this, "fadein-to-fadeout");
                        break;

                }
                return true;
            }
        });
    }

    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    //Current Current Address
    public String getAddress(double lat, double lon) {
        Geocoder geoCoder = new Geocoder(this);

        List<Address> matches = null;
        try {
            matches = geoCoder.getFromLocation(lat, lon, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Address bestMatch = (matches.isEmpty() ? null : matches.get(0));


        if (bestMatch == null) {
            return "Oops ! Error 404 : Location not found";
        }
        //if(bestMatch.getAddressLine(0) == null){
        //    return "Awwww ..... Location not Found";
        //}
        return bestMatch.getAddressLine(0);

    }

    //Get Current Location
    public String getCurrentLocation() {

        LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
        Criteria criteria = new Criteria();
        String provider = locationManager.getBestProvider(criteria, true);
        assert provider != null;
        if (checkUserLocationPermission()) {
            Location location = locationManager.getLastKnownLocation(provider);
            assert location != null;
            Geocoder geoCoder = new Geocoder(this);
            List<Address> matches = null;
            try {
                matches = geoCoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
            } catch (IOException e) {
                e.printStackTrace();
            }
            if(matches == null){
                return "Oops ! Error 404 : Location not found";
            }
            Address bestMatch = (matches.isEmpty() ? null : matches.get(0));

            if (bestMatch == null) {
                return "Oops ! Error 404 : Location not found";
            }

            return bestMatch.getAddressLine(0);
        }
        return "Oops ! Error 404 : Location not found";
    }

    public boolean checkUserLocationPermission(){
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, Request_user_location_code);
            }
            else{
                ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, Request_user_location_code);
            }
            return false;
        }
        return true;
    }
    public void openDialog(String date , String address) {

        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);
        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(this).inflate(R.layout.pop_up, viewGroup, false);

        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);
        RelativeLayout color = dialogView.findViewById(R.id.color);
        color.setBackground(getResources().getDrawable(R.drawable.smart));
        ImageView icon = dialogView.findViewById(R.id.logo);
        icon.setBackground(getResources().getDrawable(R.drawable.ic_alert));
        TextView details = dialogView.findViewById(R.id.response);
        details.setText("On the " +  date  +   " at " +
                address + " someone tested postive for COVID-19, we strongly suggest taking the self test method on the app as you and the person shared a common location"   );
       details.setTextSize(16);
        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dismiss = dialogView.findViewById(R.id.dismiss);
        Button prev = dialogView.findViewById(R.id.prev);
        prev.setText("Self Check");

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        prev.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent start = new Intent(Home.this,Self_check.class);
                startActivity(start);
                CustomIntent.customType(Home.this, "fadein-to-fadeout");
            }
        });

        alertDialog.show();

    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
    public void InContact(){
        OkHttpClient client = new OkHttpClient();
        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/InContact.php").newBuilder();

        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                }
                else {

                    final String responseData = response.body().string();

                    Home.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONArray all = new JSONArray(responseData);

                                for (int i = 0; i < all.length(); i++) {

                                    JSONObject obj = all.getJSONObject(i);
                                    String lat = obj.getString("LOCATION_LATITUDE");
                                    String lon = obj.getString("LOCATION_LONGITUDE");
                                    String date = obj.getString("LOCATION_DATE");
                                    LatLng coordinate = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));

                                    openDialog(date,getAddress(coordinate.latitude,coordinate.longitude));


                                }
                            } catch (JSONException e) {
                                e.printStackTrace();

                            }

                        }
                    });
                }
            }
        });
    }
}