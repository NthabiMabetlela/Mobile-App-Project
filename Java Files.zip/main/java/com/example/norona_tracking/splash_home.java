package com.example.norona_tracking;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;

public class splash_home extends AppCompatActivity {
    private Button log,sign;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_home);

        Paper.init(this);

        String UserEmailKey = Paper.book().read(utilities.EmailKey);
        String UserPassKey = Paper.book().read(utilities.PassKey);

        // user opted for remember me ;)
        if(UserEmailKey != null && UserPassKey != null) {
            System.out.println("Sign in ;)");
            if (!UserEmailKey.isEmpty() && !UserPassKey.isEmpty()) {
                Intent i = new Intent(this, myLocation.class);
                startActivity(i);
            }
        }


        log = findViewById(R.id.login_home);
        sign = findViewById(R.id.sign_up_home);

        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sign_up_activity = new Intent(splash_home.this, Login.class);
                startActivity(sign_up_activity);
                CustomIntent.customType(splash_home.this,"left-to-right");
            }
        });

        sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sign_up_activity = new Intent(splash_home.this, Sign_up.class);
                startActivity(sign_up_activity);
                CustomIntent.customType(splash_home.this,"left-to-right");
            }
        });

    }
}
