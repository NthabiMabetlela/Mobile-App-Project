package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.util.ArrayList;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;

import static android.view.Gravity.CENTER;

public class Self_check extends AppCompatActivity {
    LinearLayout ln;
    ArrayList<String> symptoms = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_self_check);

        ActionBar toolbar = getSupportActionBar();
        toolbar.setTitle("Self Check");
        toolbar.setIcon(R.mipmap.ic_launcher);
        ln = findViewById(R.id.list_of_symptoms);

        TextView t = new TextView(this);
        t.setText("Please select the following that apply  " +  getString(R.string.legal));
        ln.addView(t);

        final Drawable uncheck = getResources().getDrawable(R.drawable.symtom_outline);
        final Drawable check = getResources().getDrawable(R.drawable.green);
        symptoms.add("Fever");
        symptoms.add("Dry cough");
        symptoms.add("Coughing up slime (producing sputum in the lungs)");
        symptoms.add("Fatigue");
        symptoms.add("Sore throat");
        symptoms.add("Shortness of breath");
        symptoms.add("Have you been in recent contact with someone who tested postive for COVID-19");


        final int[] count = {0};
        for (String i : symptoms) {
            final CheckBox checkBox = new CheckBox(this);
            checkBox.append(i);
            checkBox.setTextSize(16);
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    if (isChecked) {
                        checkBox.setBackground(uncheck);
                        count[0]++;
                    } else {
                        checkBox.setBackground(check);
                        count[0]--;
                    }
                }
            });
            ln.addView(checkBox);
        }
        TextView hotline = new TextView(this);
        hotline.setTextSize(16);
        hotline.setTextColor(Color.BLACK);
        hotline.setText("COIVD HOTLINE : 0800 029 999");
        ln.addView(hotline);

        Drawable d = getResources().getDrawable(R.drawable.blue);
        Button b = new Button(this);
        b.setText("Check");
        b.setTextColor(Color.WHITE);
        b.setGravity(CENTER);
        b.setBackground(d);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count[0] == 0) {
                    Toast.makeText(Self_check.this, "You have no common COVID-19 symptoms", Toast.LENGTH_LONG).show();
                } else if (count[0] < 3) {
                    Toast.makeText(Self_check.this, "You have some symtpoms of COVID-19 , if symptoms persist contact your Healthcare provider", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(Self_check.this, "Contact your healthcare provider ASAP", Toast.LENGTH_LONG).show();
                }

            }
        });
        ln.addView(b);

        TextView blank = new TextView(this);
        blank.setHeight(56);
        ln.addView(blank);

        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.self_check);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home: //home
                        activity = new Intent(Self_check.this, Home.class);
                        startActivity(activity);
                        CustomIntent.customType(Self_check.this,"fadein-to-fadeout");
                        break;

                    case R.id.search: //unknown
                        startActivity(new Intent(Self_check.this, Search.class));
                        CustomIntent.customType(Self_check.this, "fadein-to-fadeout");
                        return true;

                    case R.id.myLocations:
                        startActivity(new Intent(Self_check.this,myLocation.class));
                        CustomIntent.customType(Self_check.this,"fadein-to-fadeout");
                        return true;

                    case R.id.self_check:
                        return true;

                    case R.id.Stats:
                        startActivity(new Intent(Self_check.this,Map_graph.class));
                        CustomIntent.customType(Self_check.this,"fadein-to-fadeout");
                        return true;
                }
                return true;
            }
        });


    }
    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }
}

