package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;

public class Map_graph extends AppCompatActivity {
    private WebView webView;
    BottomNavigationView navigationView;
    BottomNavigationView map_navbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_map_graph);

        ActionBar toolbar = getSupportActionBar();
        toolbar.setTitle("Statistics");
        toolbar.setIcon(R.mipmap.ic_launcher);
        /*** Nav Bar Top ****/
        navigationView = (BottomNavigationView) findViewById(R.id.map_nav);
        navigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.nav_map:
                        return true;
                    case R.id.nav_stats:
                        Intent Map_graph = new Intent(Map_graph.this,Map_summary.class);
                        startActivity(Map_graph);
                        CustomIntent.customType(Map_graph.this,"left-to-right");
                        return true;

                }
                return true;
            }
        });

        /*** Setting up the Nav Bar Bottom ****/
        map_navbar = findViewById(R.id.navigation);
        map_navbar.setSelectedItemId(R.id.Stats);


        map_navbar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        activity = new Intent(Map_graph.this, Home.class);
                        startActivity(activity);
                        CustomIntent.customType(Map_graph.this,"fadein-to-fadeout");
                        break;
                    case R.id.search:
                        startActivity(new Intent(Map_graph.this, Search.class));
                        CustomIntent.customType(Map_graph.this, "fadein-to-fadeout");
                        return true;
                    case R.id.myLocations:
                        startActivity(new Intent(Map_graph.this,myLocation.class));
                        CustomIntent.customType(Map_graph.this,"fadein-to-fadeout");
                        return true;
                    case R.id.self_check:
                        startActivity(new Intent(Map_graph.this,Self_check.class));
                        CustomIntent.customType(Map_graph.this,"fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        return true;

                }
                return true;
            }
        });

        if(!isNetworkAvailable()){
            Intent no_internet = new Intent(this,no_internet.class);
            startActivity(no_internet);
            CustomIntent.customType(this,"rotateout-to-rotatein");
        }
        else{
            webView = (WebView) findViewById(R.id.web);
            webView.setWebViewClient(new WebViewClient());
            webView.loadUrl("https://news.google.com/covid19/map?hl=en-ZA&mid=%2Fm%2F01t05t&gl=ZA&ceid=ZA%3Aen");

            WebSettings webSettings = webView.getSettings();
            webSettings.setJavaScriptEnabled(true);
        }




    } //end Oncreate

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
