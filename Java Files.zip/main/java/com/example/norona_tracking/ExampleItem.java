package com.example.norona_tracking;

import android.graphics.drawable.Drawable;

//this is a custom object used for each card and use all of this to fill out our recycler view item
public class ExampleItem {
    //creating 3 variables here: one for our image and two for our texts
    private int mImageResource;
    private String mText1;
    private String getmText1;
    private String mText2;

    public ExampleItem(int mImage, String text1, String text2){
        mImageResource = mImage;
        mText1 = text1;
        mText2 = text2;
    }

    public int getmImageResource(){
        return mImageResource;
    }

    public String getText1(){
        return mText1;
    }

    public String getText2(){
        return mText2;
    }
}
