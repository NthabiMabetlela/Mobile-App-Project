package com.example.norona_tracking;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

import org.jetbrains.annotations.NotNull;
import android.text.method.ScrollingMovementMethod;
import java.io.IOException;

import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Sign_up extends AppCompatActivity {
    public boolean confirmed_pass;
    private  EditText emailid,pass,name,surname,c_password;
    private Button register;
    private FirebaseAuth mAuth;
    private CheckBox TC;
    private EditText confirm;
    private TextView back;
    DataBaseHelper db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        db = new DataBaseHelper(this);
        mAuth = FirebaseAuth.getInstance();
        emailid = (EditText)findViewById(R.id.email);
        pass = (EditText)findViewById(R.id.password_s);
        register = (Button)findViewById(R.id.signUpBtn);
        TC = findViewById(R.id.terms_conditions);
        confirm = (EditText)findViewById(R.id.confirmPassword);
        name = (EditText)findViewById(R.id.Name);
        surname = findViewById(R.id.surname);
        final String user = name.getText().toString();
        /** Already a User ***/

        TextView already_user = findViewById(R.id.already_user);
        already_user.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent profile = new Intent(Sign_up.this, Login.class); //go back to login
                startActivity(profile);
            }
        });

        /*** Go back home ****/

        back = findViewById(R.id.back_acc);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sign_up_activity = new Intent(Sign_up.this,splash_home.class);
                startActivity(sign_up_activity);
                CustomIntent.customType(Sign_up.this,"right-to-left");
            }
        });

        /*** Terms and Conditions **/

        TextView tc = findViewById(R.id.TC);
        tc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
        /** Register Button *****/
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String email = emailid.getText().toString();
                final String pwd = pass.getText().toString();
                String o_pass = pass.getText().toString();
                String c_pass = confirm.getText().toString();
                final String fname = name.getText().toString();
                final String lname = surname.getText().toString();

                if (TextUtils.isEmpty(pwd)) {
                    pass.setError("No Password");
                    return;
                }
                if(TextUtils.isEmpty(fname) || TextUtils.isEmpty(lname)){
                    name.setError("Name is empty");
                    surname.setError("Surname is empty");
                }
                if (TextUtils.isEmpty(email)) {
                    emailid.setError("Invalid Email");
                    return;
                }
                if (pwd.length() < 6) {
                    pass.setError("Password must be greater than 6 charcters");
                    return;
                }
                if(c_pass.isEmpty() || o_pass.isEmpty()){
                    Toast.makeText(Sign_up.this, "Please fill in a password",
                            Toast.LENGTH_SHORT).show();
                    confirm.setError("no confirmation password found");
                    return;
                }
                if(!c_pass.equals(o_pass)){
                    Toast.makeText(Sign_up.this, "Passwords do not match",
                            Toast.LENGTH_SHORT).show();
                    confirm.setError("Passwords do not match");
                    return;
                }
                if(!TC.isChecked()){
                    Toast.makeText(Sign_up.this, "Please Agree to our Terms and Conditions",
                            Toast.LENGTH_SHORT).show();
                    TC.setError("Required");
                    return;
                }
                else {
                    if(isNetworkAvailable())
                    {
                        //Create User
                        OkHttpClient client = new OkHttpClient();
                        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/SignupUser.php").newBuilder();
                        urlBuilder.addQueryParameter("USER_NAME", fname);
                        urlBuilder.addQueryParameter("USER_SURNAME", lname);
                        urlBuilder.addQueryParameter("USER_EMAIL", email);
                        urlBuilder.addQueryParameter("USER_PASSWORD", pwd);

                        String url = urlBuilder.build().toString();
                        final Request request = new Request.Builder()
                                .url(url)
                                .build();

                        client.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(Call call, Response response) throws IOException {
                                if (!response.isSuccessful()) {
                                    throw new IOException("Unexpected code " + response);
                                } else {

                                    final String responseData = response.body().string();
                                    Sign_up.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            try{
                                                UserCreated(responseData);
                                            }
                                            catch (Exception e){
                                                e.printStackTrace();
                                            }
                                        }
                                    });


                                }
                            }
                        });

                     }


                    else{ //offline mode
                        if(!db.checkUser(user,email,pwd)){
                            long val = db.addUser(user,email,pwd);
                            if (val > 0) { //works ;)
                                String s = "Account for ";
                                s = s + user + " created";
                                Toast.makeText(Sign_up.this, s,Toast.LENGTH_LONG).show();
                                Intent profile = new Intent(Sign_up.this, myLocation.class); //go back to login
                                startActivity(profile);
                            }
                            else{ //no work ;(
                                Toast.makeText(Sign_up.this, "Error Account has NOT been created",
                                        Toast.LENGTH_LONG).show();
                            }
                        }
                        else{ //already a user
                            Toast.makeText(Sign_up.this, "Account already created",Toast.LENGTH_LONG).show();
                            Intent profile = new Intent(Sign_up.this, Login.class); //go back to login
                            startActivity(profile);
                        }
                    }


                }
            }
        });

        /**show password***/
        final TextView show_hide = (TextView)findViewById(R.id.show_pass2);
        show_hide.setVisibility(View.GONE);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(pass.getText().length() > 0){
                    show_hide.setVisibility(View.VISIBLE);
                }
                else{
                    show_hide.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {}
        });
        show_hide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(show_hide.getText().equals(" ")){
                    show_hide.setText(".");
                    pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    pass.setSelection(pass.length());
                    Drawable d = getResources().getDrawable(R.drawable.show);
                    show_hide.setBackground(d);
                }
                else{
                    show_hide.setText(" ");
                    pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    pass.setSelection(pass.length());
                    Drawable d = getResources().getDrawable(R.drawable.eye);
                    show_hide.setBackground(d);
                }
            }
        });

        //*** confirm password show.hide ***//
        final TextView visibility = (TextView)findViewById(R.id.show_pass1);
        visibility.setVisibility(View.GONE);
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirm.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(confirm.getText().length() > 0){
                    visibility.setVisibility(View.VISIBLE);
                }
                else{
                    visibility.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {}
        });

        visibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(visibility.getText().equals(" ")){
                    visibility.setText(".");
                    confirm.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    confirm.setSelection(confirm.length());
                    Drawable d = getResources().getDrawable(R.drawable.show);
                    visibility.setBackground(d);
                }
                else{
                    visibility.setText(" ");
                    confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    confirm.setSelection(confirm.length());
                    Drawable d = getResources().getDrawable(R.drawable.eye);
                    visibility.setBackground(d);
                }
            }
        });


    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public boolean UserCreated(String response){

        if(response.equals("Success")){
            Toast.makeText(this,"Account Created Successfully",Toast.LENGTH_LONG).show();
            Intent success = new Intent(this,Login.class);
            startActivity(success);
            CustomIntent.customType(this,"fadein-to-fadeout");
            return true;
        }
        else{
            Toast.makeText(this,"Oops!,This email has already been registered , Try Again ....",Toast.LENGTH_LONG).show();
        }
        return false;
    }
    public void openDialog() {


        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);
        //then we will inflate the custom alert dialog xml that we created
        View dialogView = LayoutInflater.from(this).inflate(R.layout.pop_up, viewGroup, false);

        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dismiss = dialogView.findViewById(R.id.dismiss);
        Button prev = dialogView.findViewById(R.id.prev);

            RelativeLayout relativeLayout = dialogView.findViewById(R.id.color);
            relativeLayout.setBackground(getResources().getDrawable(R.drawable.blue));
            TextView text = dialogView.findViewById(R.id.response);
            text.setText(R.string.tc);
            text.setTextSize(12);
            text.setMovementMethod(new ScrollingMovementMethod());
            text.setTextColor(getResources().getColor(R.color.col_Mblue));

            prev.setText(" ");

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });


        alertDialog.show();

    }


}
