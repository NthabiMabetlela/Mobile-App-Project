package com.example.norona_tracking;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import io.paperdb.Paper;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Profile extends AppCompatActivity {

    RadioGroup radioGroup;
    String statusUpdate = "0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        ActionBar toolbar = getSupportActionBar();
        toolbar.setTitle("Profile");
        toolbar.setIcon(R.mipmap.ic_launcher);

        //for the Radio Buttons
        radioGroup = (RadioGroup)findViewById(R.id.radiogroup);
        final String username = Paper.book().read(utilities.id).toString();

        TextView name,surname,email;
        name = findViewById(R.id.name); surname = findViewById(R.id.surname);email = findViewById(R.id.email);
        name.setText(Paper.book().read(utilities.username).toString());
        surname.setText(Paper.book().read(utilities.surname).toString());
        email.setText(Paper.book().read(utilities.EmailKey).toString());
        String cv = Paper.book().read(utilities.virus).toString();

        if(cv.equals("1")) {
            radioGroup.check(R.id.positive);
        }
        else{
            radioGroup.check(R.id.negative);
        }

        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radiogroup, int i) {
                switch (i){
                    case R.id.positive:
                        Toast.makeText(getApplicationContext(), "Status successfully updated",
                                Toast.LENGTH_SHORT).show();
                        statusUpdate = "1";
                        //Update COVID-19 Status
                        OkHttpClient client = new OkHttpClient();
                        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/UpdateUserCovidStatus.php").newBuilder();
                        urlBuilder.addQueryParameter("USER_ID", username);
                        urlBuilder.addQueryParameter("USER_COVIDSTATUS", statusUpdate);

                        String url = urlBuilder.build().toString();
                        Request request = new Request.Builder()
                                .url(url)
                                .build();

                        // Get a handler that can be used to post to the main thread
                        client.newCall(request).enqueue(new Callback() { //after typing enqueue blah blah blah we would get the two methods onFaliure and onRespoonse
                            @Override //we run the enqueue request in the background request
                            public void onFailure(Call call, IOException e) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(Call call, final Response response) throws IOException {
                                if (response.isSuccessful()) {
                                    final String myResponse = response.body().string();
                                }
                            }
                        });

                        //end of case 1
                        break;

                    case R.id.negative:
                        Toast.makeText(getApplicationContext(), "Status successfully updated",
                                Toast.LENGTH_SHORT).show();
                        statusUpdate = "0";

                        //Update COVID-19 Status
                        client = new OkHttpClient();
                        urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/UpdateUserCovidStatus.php").newBuilder();
                        urlBuilder.addQueryParameter("USER_ID", username);
                        urlBuilder.addQueryParameter("USER_COVIDSTATUS", statusUpdate);

                        url = urlBuilder.build().toString();
                        request = new Request.Builder()
                                .url(url)
                                .build();

                        // Get a handler that can be used to post to the main thread
                        client.newCall(request).enqueue(new Callback() { //after typing enqueue blah blah blah we would get the two methods onFaliure and onRespoonse
                            @Override //we run the enqueue request in the background request
                            public void onFailure(Call call, IOException e) {
                                e.printStackTrace();
                            }

                            @Override
                            public void onResponse(Call call, final Response response) throws IOException {
                                if (response.isSuccessful()) {
                                    final String myResponse = response.body().string();
                                }
                            }
                        });

                        break;
                }
            }
        });

    }
    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }
}