package com.example.norona_tracking;

import android.content.Context;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class utilities {

    //Email Validation pattern
    public static final String regEx = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
    public static boolean Login = false,signup = false,updatecovid = false,updateLocation = false;
    public static  String mylocations;
    static boolean isValid(String email) {
        String regex = "^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$";
        return email.matches(regex);
    }



    //Validate password and Username
    public static final String EmailKey = "Email"; //remember me
    public static final String PassKey = "pass"; //remember me
    public  static  final String Sign_out = "true"; //remember me
    public static final String id = "test";
    public static final String username = "name";
    public static final String surname = "surname";
    public static final String virus = "yessir";

    ///*************************************************  OKHTTP REQUESTS **********************************************************************//

    //GetUser



    //Create User
    public static boolean CreateUser(String name , String surname,String email,String password) {
        final boolean[] Query_Ok = {false};
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/SignupUser.php").newBuilder();
        urlBuilder.addQueryParameter("USER_NAME", name);
        urlBuilder.addQueryParameter("USER_SURNAME", surname);
        urlBuilder.addQueryParameter("USER_EMAIL", email);
        urlBuilder.addQueryParameter("USER_PASSWORD", password);

        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {

                    //responseData[0] = response.body().string();
                    signup = true;

                }
            }
        });
        return signup;
    }



    // GetLocations
    public static String getLocation(String id) {
        final String[] responseData = new String[1];
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/RetrieveUsers.php").newBuilder();
        urlBuilder.addQueryParameter("user", id);
        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {
                    responseData[0] = response.body().string();
                    mylocations = responseData[0];

                }
            }
        });
        return mylocations;
    }



    // Update Locations
    public static boolean sendlocationupdate(String id , String lat,String lon,String date) {
        final String[] responseData = new String[1];
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/RetrieveLocation.php").newBuilder();
        urlBuilder.addQueryParameter("USER_ID", id);
        urlBuilder.addQueryParameter("LOCATION_LATITUDE", lat);
        urlBuilder.addQueryParameter("LOCATION_LONGITUDE", lon);
        urlBuilder.addQueryParameter("LOCATION_DATE", date);

        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {

                    responseData[0] = response.body().string();
                    updateLocation = true;

                }
            }
        });
        return updateLocation;
    }


    // Update Covid Status
    public static boolean  UpdateCovidStatus(String id,String status) {
        final String[] responseData = new String[1];
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/UpdateUserCovidStatus.php").newBuilder();
        urlBuilder.addQueryParameter("USER_ID", id);
        urlBuilder.addQueryParameter("USER_COVIDSTATUS", status);
        String url = urlBuilder.build().toString();

        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {
                    responseData[0] = response.body().string();
                    updatecovid = true;
                }
            }
        });
        return updatecovid;
    }


    //Location Merge with Covid Status



    //Calculate distance between two points
    /**
     * Calculate distance between two points in latitude and longitude taking
     * into account height difference. If you are not interested in height
     * difference pass 0.0. Uses Haversine method as its base.
     *
     * lat1, lon1 Start point lat2, lon2 End point el1 Start altitude in meters
     * el2 End altitude in meters
     * @returns Distance in Meters
     */
    public static double distance(double lat1, double lat2, double lon1,
                                  double lon2) {

        final int R = 6371; // Radius of the earth

        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        double distance = R * c * 1000; // convert to meters

        distance = Math.pow(distance, 2);

        return Math.sqrt(distance);
    }


}

