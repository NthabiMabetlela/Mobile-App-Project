package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Search extends AppCompatActivity {
    BottomNavigationView home_nav;
    ArrayList<ExampleItem> exampleList = new ArrayList<>();
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter; //Adapter is the bridge between our data (arraylist) and recyclerview.
    private RecyclerView.LayoutManager mLayoutManager;  // aligning single  items in the layout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        /*** Toolbar ****/
        ActionBar toolbar = getSupportActionBar();
        toolbar.setTitle("Search");
        toolbar.setIcon(R.mipmap.ic_launcher);

        if(!isNetworkAvailable()){
            Intent wifi = new Intent(this,no_internet.class);
            startActivity(wifi);
        }

        /**** Content *****/

        OkHttpClient client = new OkHttpClient();

        String url = "https://lamp.ms.wits.ac.za/home/s1828559/JoinCount.php"; //we get our JSON from this URL. Download it then display in our text view

        Request request = new Request.Builder()
                .url(url)
                .build();

// Get a handler that can be used to post to the main thread
        client.newCall(request).enqueue(new Callback() { //after typing enqueue blah blah blah we would get the two methods onFaliure and onRespoonse
            @Override //we run the enqueue request in the background request
            public void onFailure(Call call, IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, final Response response) throws IOException {
                if (response.isSuccessful()) {
                    final String myResponse = response.body().string();
                    //want to display this in our text view
                    Search.this.runOnUiThread(new Runnable() {

                        @Override
                        public void run() { //to access text view in main thread
                            String json = myResponse;
                            JSONArray ja = null;
                            String Cresta = "0";

                            String[] locationArray = {"0", "0", "0", "0", "0","0"};

                            try {
                                ja = new JSONArray(json);
                                for (int i = 0; i < ja.length(); i++) {
                                    JSONObject jo = ja.getJSONObject(i);

                                    Cresta = jo.getString("count");
                                    locationArray [i] = Cresta;

                                }
                            } catch (JSONException e) {
                                e.printStackTrace();
                            }

                            //example thingy because if we run this below before the OkHttp we are going to get a blank page
                            //Creating an ArrayList for our images.
                            exampleList.add(new ExampleItem(R.drawable.cresta_mall, "Cresta Mall", "Number of infected people     " + locationArray[0])); //Adding items now. Then create new items. Pass an image resource and our texts
                            exampleList.add(new ExampleItem(R.drawable.clearwater_mall, "Clearwater Mall", "Number of infected people     " + locationArray[1] ));
                            exampleList.add(new ExampleItem(R.drawable.makro_woodmead, "Makro, Woodmead", "Number of infected people     " + locationArray[2]));
                            exampleList.add(new ExampleItem(R.drawable.goldman_crossing_spar, "Goldman Spar , Roodepoort", "Number of infected people     " + locationArray[3]));
                            exampleList.add(new ExampleItem(R.drawable.engen_empire, "Engen Empire Service Centre", "Number of infected people     " + locationArray[4]));
                            exampleList.add(new ExampleItem(R.drawable.westpack_lifestyle, "Westpack Lifestyle, Roodepoort", "Number of infected people     " + locationArray[5]));

                            mRecyclerView = findViewById(R.id.recyclerView); //initialize our recyclerview
                            mRecyclerView.setHasFixedSize(true); //our recycler won't change in size. The items will not increase or decrease.

                            mLayoutManager = new LinearLayoutManager(Search.this);
                            mAdapter = new ExampleAdapter(exampleList);
                            mRecyclerView.setLayoutManager(mLayoutManager);
                            mRecyclerView.setAdapter(mAdapter);

                        }
                    });

                }
            }
        });

        /***************************************************************/

        home_nav = findViewById(R.id.navigation);
        home_nav.setSelectedItemId(R.id.search);

        home_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        startActivity(new Intent(Search.this, Home.class));
                        CustomIntent.customType(Search.this, "fadein-to-fadeout");
                        return true;
                    case R.id.search:
                        return true;
                    case R.id.myLocations:
                        startActivity(new Intent(Search.this, myLocation.class));
                        CustomIntent.customType(Search.this, "fadein-to-fadeout");
                        return true;
                    case R.id.self_check:
                        startActivity(new Intent(Search.this, Self_check.class));
                        CustomIntent.customType(Search.this, "fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        activity = new Intent(Search.this, Map_graph.class);
                        startActivity(activity);
                        CustomIntent.customType(Search.this, "fadein-to-fadeout");
                        break;

                }
                return true;
            }
        });
    }
    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }
}