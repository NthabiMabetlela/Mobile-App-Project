package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.jetbrains.annotations.NotNull;

import java.io.IOException;

import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class forgot_password extends AppCompatActivity {


    private FirebaseAuth mAuth;
    private EditText Email;
    private TextView reset;
    public String email;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_password);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser user = mAuth.getCurrentUser();
        Email = findViewById(R.id.email);
        Button submit = findViewById(R.id.submit);
        email = Email.getText().toString();
        final EditText pass = (EditText)findViewById(R.id.password_s), confirm = (EditText)findViewById(R.id.confirmPassword);
        //reset = findViewById(R.id.reset);

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String email = Email.getText().toString().trim();
                if (TextUtils.isEmpty(email) || !utilities.isValid(email) ) {
                    Toast.makeText(getApplicationContext(), "Please enter a valid email", Toast.LENGTH_SHORT).show();
                    Email.setError("Invalid E-mail address");
                    return;
                }
                else{
                    openDialog(email);
                }

            }
        });

    }

    public void openDialog(final String mail) {

        //before inflating the custom alert dialog layout, we will get the current activity viewgroup
        ViewGroup viewGroup = findViewById(android.R.id.content);
        //then we will inflate the custom alert dialog xml that we created
        final View dialogView = LayoutInflater.from(this).inflate(R.layout.reset_password, viewGroup, false);

        //Now we need an AlertDialog.Builder object
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        //setting the view of the builder to our custom view that we already inflated
        builder.setView(dialogView);

        //finally creating the alert dialog and displaying it
        final AlertDialog alertDialog = builder.create();

        Button dismiss = dialogView.findViewById(R.id.dismiss);
        Button prev = dialogView.findViewById(R.id.prev);

        final EditText pass = dialogView.findViewById(R.id.password_s), confirm = dialogView.findViewById(R.id.confirmPassword);

        /**** PASSWORD STUFF *************/
        /**show password***/
        final TextView show_hide = (TextView)dialogView.findViewById(R.id.show_pass1);
        show_hide.setVisibility(View.GONE);
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(pass.getText().length() > 0){
                    show_hide.setVisibility(View.VISIBLE);
                }
                else{
                    show_hide.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {}
        });
        show_hide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(show_hide.getText().equals(" ")){
                    show_hide.setText(".");
                    pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    pass.setSelection(pass.length());
                    Drawable d = getResources().getDrawable(R.drawable.show);
                    show_hide.setBackground(d);
                }
                else{
                    show_hide.setText(" ");
                    pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    pass.setSelection(pass.length());
                    Drawable d = getResources().getDrawable(R.drawable.eye);
                    show_hide.setBackground(d);
                }
            }
        });

        //*** confirm password show.hide ***//
        final TextView visibility = (TextView)dialogView.findViewById(R.id.show_pass2);
        visibility.setVisibility(View.GONE);
        confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        confirm.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(confirm.getText().length() > 0){
                    visibility.setVisibility(View.VISIBLE);
                }
                else{
                    visibility.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {}
        });

        visibility.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(visibility.getText().equals(" ")){
                    visibility.setText(".");
                    confirm.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    confirm.setSelection(confirm.length());
                    Drawable d = getResources().getDrawable(R.drawable.show);
                    visibility.setBackground(d);
                }
                else{
                    visibility.setText(" ");
                    confirm.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    confirm.setSelection(confirm.length());
                    Drawable d = getResources().getDrawable(R.drawable.eye);
                    visibility.setBackground(d);
                }
            }
        });



        /********************************/

        dismiss.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        prev.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                final TextView body = dialogView.findViewById(R.id.response);
                final String pwd = pass.getText().toString();
                String o_pass = pass.getText().toString();
                String c_pass = confirm.getText().toString();

                if (pwd.length() < 6) {
                    pass.setError("Password must be greater than 6 charcters");
                    return;
                }
                if (c_pass.isEmpty() || o_pass.isEmpty()) {
                    Toast.makeText(forgot_password.this, "Please fill in a password",
                            Toast.LENGTH_SHORT).show();
                    confirm.setError("no confirmation password found");
                    return;
                }
                if (!c_pass.equals(o_pass)) {
                    Toast.makeText(forgot_password.this, "Passwords do not match",
                            Toast.LENGTH_SHORT).show();
                    confirm.setError("Passwords do not match");
                    return;
                } else {

                    OkHttpClient client = new OkHttpClient();

                    HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/ForgotPassword.php").newBuilder();
                    urlBuilder.addQueryParameter("password", pass.getText().toString());
                    urlBuilder.addQueryParameter("email",mail);
                    String url = urlBuilder.build().toString();
                    System.out.println(url + " dasfjjksdjfkldsjfklsdjflksdjflkjsdlkfjsdlkfjslkdfjslkdfjslkd");
                    final Request request = new Request.Builder()
                            .url(url)
                            .build();

                    client.newCall(request).enqueue(new Callback() {
                        @Override
                        public void onFailure(@NotNull Call call, @NotNull IOException e) {
                            e.printStackTrace();
                        }

                        @Override
                        public void onResponse(Call call, final Response response) throws IOException {
                            final String responseData = response.body().string();
                            if (!response.isSuccessful()) {
                                throw new IOException("Unexpected code " + response);
                            } else {
                                    forgot_password.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            if(responseData.equals("Success")){
                                                body.setText("Password successfully updated");
                                                Toast.makeText(forgot_password.this,"Password Updated", Toast.LENGTH_LONG).show();
                                                try {
                                                    Thread.sleep(2000);
                                                    Intent start = new Intent(forgot_password.this,Login.class);
                                                    startActivity(start);
                                                } catch (InterruptedException e) {
                                                    e.printStackTrace();
                                                }

                                            }
                                            else{
                                                body.setText("Oops! Something went wrong , password unchanged");
                                            }
                                        }
                                    });

                            }
                        }
                    });
                }
            }
        });


        alertDialog.show();

    }



}
