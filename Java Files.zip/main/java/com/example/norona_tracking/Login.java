package com.example.norona_tracking;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.facebook.CallbackManager;
import com.facebook.login.widget.LoginButton;
import com.google.firebase.auth.FirebaseAuth;
import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;



import static android.widget.Toast.LENGTH_SHORT;


public class Login extends AppCompatActivity {
    private  EditText emailid;
    private  EditText password;
    private FirebaseAuth mAuth;
    private  ProgressBar progressBar;
    private TextView back;
    private CheckBox remember;
    private CallbackManager callbackManager;
    private LoginButton fb_login;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_login);

        back = findViewById(R.id.back_log);
        emailid = findViewById(R.id.username);
        password = findViewById(R.id.password);


        Paper.init(this);



        remember = findViewById(R.id.checkBox);



        /**** Go back to home Screen***/
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent sign_up_activity = new Intent(Login.this, splash_home.class);
                startActivity(sign_up_activity);
                CustomIntent.customType(Login.this,"right-to-left");
            }
        });

        /**sign up button***/
        TextView sign_up = (TextView)findViewById(R.id.create_user);
        sign_up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startsignup();
            }

            public void startsignup() {
                Intent sign_up_activity = new Intent(Login.this, Sign_up.class);
                startActivity(sign_up_activity);
                CustomIntent.customType(Login.this,"fadein-to-fadeout");
            }
        });

        /**forgot your password**/

        TextView forgot = (TextView) findViewById(R.id.for_pass);
        forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //startforgotpass();
                Intent forgot_activity = new Intent(Login.this, forgot_password.class);
                startActivity(forgot_activity);

            }
        });




        /**SHow/hide password**/
        final TextView show_hide = (TextView)findViewById(R.id.show_pass1);
        show_hide.setVisibility(View.GONE);
        password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if(password.getText().length() > 0){
                    show_hide.setVisibility(View.VISIBLE);
                }
                else{
                    show_hide.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {}
        });
        show_hide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(show_hide.getText().equals(" ")){
                    show_hide.setText(".");
                    password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    password.setSelection(password.length());
                    Drawable d = getResources().getDrawable(R.drawable.show);
                    show_hide.setBackground(d);
                }
                else{
                    show_hide.setText(" ");
                    password.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    password.setSelection(password.length());
                    Drawable d = getResources().getDrawable(R.drawable.eye);
                    show_hide.setBackground(d);
                }
            }
        });




        /***Login in***/
        final Button login = (Button) findViewById(R.id.sign_in);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String getEmailId = emailid.getText().toString();
                final String getPassword = password.getText().toString();
                checkValidation();

                    DataBaseHelper db = new DataBaseHelper(Login.this);

                    //time for a Login
                    emailid.getText().clear();
                    password.getText().clear();

                    if(!isNetworkAvailable() && db.checkUser("name",getEmailId,getPassword)){ //no internet connection

                        /** Remember me **/
                        if(remember.isChecked()){
                            Paper.book().write(com.example.norona_tracking.utilities.EmailKey,getEmailId);
                            Paper.book().write(com.example.norona_tracking.utilities.PassKey,getPassword);
                        }
                        /** End of remember me ****/

                        Toast.makeText(Login.this, "You're Back ! ", Toast.LENGTH_LONG).show();
                        Intent i = new Intent(Login.this,myLocation.class);
                        startActivity(i);
                    }

               /**** Start of OKHTTP REQUESTS FOR LOGIN ********/


                OkHttpClient client = new OkHttpClient();
                HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/RetrieveUsers.php").newBuilder();
                urlBuilder.addQueryParameter("pass", getPassword);
                urlBuilder.addQueryParameter("email",getEmailId);
                String url = urlBuilder.build().toString();
                final Request request = new Request.Builder()
                        .url(url)
                        .build();

                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(@NotNull Call call, @NotNull IOException e) {
                        e.printStackTrace();
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        if (!response.isSuccessful()) {
                            throw new IOException("Unexpected code " + response);
                        }
                        else {

                            final String responseData = response.body().string();

                            Login.this.runOnUiThread(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                       boolean c =  Verify(responseData,getPassword, getEmailId);
                                       System.out.println(getEmailId + "dsjkfhjksdf");
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                        }
                    }
                });



                }

        });


    }






    private void checkValidation() {

        // Get email id and password
        String getEmailId = emailid.getText().toString();
        String getPassword = password.getText().toString();

        // Check patter for email id
        Pattern p = Pattern.compile(utilities.regEx);

        Matcher m = p.matcher(getEmailId);

        // Check for both field is empty or not
        if (getEmailId.equals("") || getEmailId.length() == 0
                || getPassword.equals("") || getPassword.length() == 0) {
            emailid.setError("No Email has been provided");
            password.setError("No password has been provided");
            Toast toast = Toast.makeText(getApplicationContext(), "Please enter both credentials", LENGTH_SHORT);
            toast.show();

        }
        else {
            // Check if email id is valid or not
            if (getPassword.length() < 0) { //change this
                password.setError("No password provided");
                Toast t = Toast.makeText(getApplicationContext(), "Enter valid password", LENGTH_SHORT);
                t.show();
            }

            if (emailid.length() < 0) { //change this
                emailid.setError("No Email has been provided");
                Toast t = Toast.makeText(getApplicationContext(), "Enter valid password", LENGTH_SHORT);
                t.show();
            }
            // Else do login and do your stuff
            if (!utilities.isValid(getEmailId)) {
                //FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                //String name = user.getDisplayName().toString();
                String welcome = "Invalid Email address";
                //welcome = welcome.concat(name);
                Toast.makeText(getApplicationContext(), welcome, LENGTH_SHORT)
                        .show();

            }
        }
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public Boolean processJSON(String json,String password){
        String s = "";
        String email = "";
        String pass = "";
        if(json == null){
            Toast.makeText(this,"Json is Null 0_0",Toast.LENGTH_LONG).show();
            return false;
        }
        else {
            try {
                JSONArray all = new JSONArray(json);
                for (int i = 0; i < all.length(); i++) {
                    JSONObject obj = all.getJSONObject(i);
                    String id = obj.getString("USER_ID");
                    email = obj.getString("USER_EMAIL");
                    pass = obj.getString("USER_PASSWORD");
                    s += "Email : " + email +" " + "Pass : " + pass;
                    Toast.makeText(this,s,Toast.LENGTH_LONG).show();
                    Paper.book().write(utilities.id,id);
                    return true;
                }
            } catch (JSONException e) {
                e.printStackTrace();
                return false;
            }
        }
        return true;
    }

    public boolean Verify(String json,String Password ,String Email){
        try {

            JSONArray all = new JSONArray(json);
            if(all.length() == 0){
                Toast.makeText(Login.this,"Oops! , Wrong username/password",Toast.LENGTH_LONG).show();
                return false;
            }
            else{
            for (int i=0; i<all.length(); i++) {
                JSONObject item = all.getJSONObject(i);
                String id = item.getString("USER_ID");
                String surname = item.getString("USER_SURNAME");
                String name = item.getString("USER_NAME");
                String email = item.getString("USER_EMAIL");
                String covid = item.getString("USER_COVIDSTATUS");
                System.out.println(email + "test");

                Paper.book().write(utilities.id, id); // User ID saved
                Paper.book().write(utilities.username, name); //user name saved
                Paper.book().write(utilities.surname, surname); //surname saved
                Paper.book().write(utilities.virus, covid); //covid status saved
                Paper.book().write(com.example.norona_tracking.utilities.EmailKey, Email); //email is saved

                    /** Remember me **/
                    if (remember.isChecked()) {
                        Paper.book().write(com.example.norona_tracking.utilities.EmailKey, Email);
                        Paper.book().write(com.example.norona_tracking.utilities.PassKey, Password);
                    }
                    /** End of remember me ****/
                    Toast.makeText(Login.this, "You're Back ! ", Toast.LENGTH_LONG).show();
                    Intent success = new Intent(Login.this, myLocation.class);
                    startActivity(success);
                    return true;

             }
            }
        } catch (JSONException e) {
            e.printStackTrace();
            return false;
        }
        return false;
    }


}


