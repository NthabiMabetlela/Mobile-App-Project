package com.example.norona_tracking;

import android.content.Context;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.AbsListView;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;

import static android.graphics.Color.parseColor;


public class rows extends TableRow {


    public rows(Context context) {
        super(context);
    }




    public TableRow add(String s1,String s2){

        TableRow tr = new TableRow(getContext());
        tr.setLayoutParams(new LayoutParams(
                LayoutParams.FILL_PARENT,
                LayoutParams.WRAP_CONTENT));

        TextView location = new TextView(getContext());
        TextView date = new TextView(getContext());


        location.setTextColor(getResources().getColor(R.color.black));
        location.setTextSize(16);
        location.setBackgroundColor(parseColor("#54780419"));
        location.setTextColor(parseColor("#FFFFFF"));
        location.setText(s1);
        location.setGravity(Gravity.CENTER);
        TableRow.LayoutParams l_p = new TableRow.LayoutParams(0, LayoutParams.MATCH_PARENT, 7f);
        location.setLayoutParams(l_p);
        tr.addView(location);

        date.setTextColor(getResources().getColor(R.color.black));
        date.setTextSize(16);
        date.setTextColor(parseColor("#FFFFFF"));
        date.setBackgroundColor(parseColor("#725F87A8"));
        date.setText(s2);
        date.setGravity(Gravity.CENTER);
        TableRow.LayoutParams d_p = new TableRow.LayoutParams(0, LayoutParams.MATCH_PARENT, 3f);
        date.setLayoutParams(d_p);
        tr.addView(date);
        return tr;
    }


}
