package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.varunest.sparkbutton.SparkButton;
import com.varunest.sparkbutton.SparkEventListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class Previous_locations extends AppCompatActivity {
    TableLayout tableLayout;
    SparkButton fetch, clear;
    BottomNavigationView home_nav;

    public ArrayList<TableRow> tablerows = new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_previous_locations);

        Paper.init(this);

        fetch = findViewById(R.id.printlocation);
        clear = findViewById(R.id.clear);
        tableLayout = findViewById(R.id.locations);

        ActionBar toolbar = getSupportActionBar();
        String name = Paper.book().read(utilities.username);
        toolbar.setTitle(name + "'s" + " past locations");
        toolbar.setIcon(R.mipmap.ic_launcher);


       /* clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    for(TableRow remove : tablerows){
                        tableLayout.removeView(remove);
                    }
            }
        });*/
        if(!isNetworkAvailable()){
            Intent no_internet = new Intent(this,no_internet.class);
            startActivity(no_internet);
            CustomIntent.customType(this,"rotateout-to-rotatein");
        }

        clear.setEventListener(new SparkEventListener(){
            @Override
            public void onEvent(ImageView button, boolean buttonState) {
                if (buttonState) {
                    for(TableRow remove : tablerows){
                        tableLayout.removeView(remove);
                    }
                } else {

                    for(TableRow remove : tablerows){
                        tableLayout.removeView(remove);
                    }
                }
            }

            @Override
            public void onEventAnimationEnd(ImageView button, boolean buttonState) {

            }

            @Override
            public void onEventAnimationStart(ImageView button, boolean buttonState) {

            }
        });
        fetch.setEventListener(new SparkEventListener() {
            @Override
            public void onEvent(ImageView button, boolean buttonState) {

                        OkHttpClient client = new OkHttpClient();

                        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/RetrieveLocation.php").newBuilder();
                        urlBuilder.addQueryParameter("user", Paper.book().read(utilities.id).toString() );
                        String url = urlBuilder.build().toString();
                        final Request request = new Request.Builder()
                                .url(url)
                                .build();
                        client.newCall(request).enqueue(new Callback() {
                            @Override
                            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                                e.printStackTrace();
                            }
                            @Override
                            public void onResponse(Call call, Response response) throws IOException {
                                String responseData = "";
                                if (!response.isSuccessful()) {
                                    throw new IOException("Unexpected code " + response);
                                } else {
                                    responseData = response.body().string();

                                    final String finalResponseData = responseData;
                                    Previous_locations.this.runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            processJSON(finalResponseData);
                                        }
                                    });


                                }
                            }
                        });

                    }



            @Override
            public void onEventAnimationEnd(ImageView button, boolean buttonState) {

            }

            @Override
            public void onEventAnimationStart(ImageView button, boolean buttonState) {

            }
        });

        /*** Setting up the Nav Bar ****/
        home_nav = findViewById(R.id.navigation);
        home_nav.setSelectedItemId(R.id.myLocations);

        home_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        startActivity(new Intent(Previous_locations.this,Home.class));
                        CustomIntent.customType(Previous_locations.this,"fadein-to-fadeout");
                        return true;
                    case R.id.search:
                        //TODO
                        return true;
                    case R.id.myLocations:
                        return true;
                    case R.id.self_check:
                        startActivity(new Intent(Previous_locations.this,Self_check.class));
                        CustomIntent.customType(Previous_locations.this,"fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        activity = new Intent(Previous_locations.this, Map_graph.class);
                        startActivity(activity);
                        CustomIntent.customType(Previous_locations.this,"fadein-to-fadeout");
                        break;

                }
                return true;
            }
        });

    }


    public String getAddress(double lat , double lon){
        Geocoder geoCoder = new Geocoder(this);

        List<Address> matches = null;
        try {
            matches = geoCoder.getFromLocation(lat, lon, 1);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Address bestMatch = (matches.isEmpty() ? null : matches.get(0));


        if(bestMatch == null){
            return "Awwww ..... Location not Found";
        }
        //if(bestMatch.getAddressLine(0) == null){
        //    return "Awwww ..... Location not Found";
        //}
       return bestMatch.getAddressLine(0);

    }

    public void processJSON(String json){
        DecimalFormat df = new DecimalFormat("###.######");
        try {
            JSONArray all = new JSONArray(json);
            for(int i = 0;i < all.length();i++){
                System.out.println("it is working -0-");
                JSONObject obj = all.getJSONObject(i);
                String lat = obj.getString("LOCATION_LATITUDE");
                String lon = obj.getString("LOCATION_LONGITUDE");
                String date = obj.getString("LOCATION_DATE");
                double a_lat = Double.parseDouble(lat);
                double a_lon = Double.parseDouble(lon);
                String address = getAddress(a_lat, a_lon);
                rows s = new rows(this);
                TableRow row = s.add(address,date);
                tablerows.add(row);
                tableLayout.addView(row);
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }

    }
    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}