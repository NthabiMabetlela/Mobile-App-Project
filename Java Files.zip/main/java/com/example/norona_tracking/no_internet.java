package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;

public class no_internet extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_no_internet);


       BottomNavigationView home_nav = findViewById(R.id.navigation);
        home_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        startActivity(new Intent(no_internet.this, Home.class));
                        CustomIntent.customType(no_internet.this, "fadein-to-fadeout");
                        return true;
                    case R.id.search:
                        //TODO
                        startActivity(new Intent(no_internet.this, Search.class));
                        CustomIntent.customType(no_internet.this, "fadein-to-fadeout");
                        return true;

                        case R.id.myLocations:
                        startActivity(new Intent(no_internet.this, myLocation.class));
                        CustomIntent.customType(no_internet.this, "fadein-to-fadeout");
                        return true;
                    case R.id.self_check:
                        startActivity(new Intent(no_internet.this, Self_check.class));
                        CustomIntent.customType(no_internet.this, "fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        activity = new Intent(no_internet.this, Map_graph.class);
                        startActivity(activity);
                        CustomIntent.customType(no_internet.this, "fadein-to-fadeout");
                        break;

                }
                return true;
            }
        });
    }

    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }
}