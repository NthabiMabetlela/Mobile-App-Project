package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.varunest.sparkbutton.SparkButton;
import com.varunest.sparkbutton.SparkEventListener;

import org.jetbrains.annotations.NotNull;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.Set;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;
import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

import static android.Manifest.permission.ACCESS_FINE_LOCATION;


public class myLocation extends FragmentActivity implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks, GoogleApiClient.OnConnectionFailedListener, LocationListener {
    public String server_response;
    public boolean success = true,ping = false;
    private GoogleMap mMap;
    private GoogleApiClient googleApiClient;
    private LocationRequest locationRequest;
    private Location lastlocation;
    OkHttpClient client;
    Set<LatLng> past_locations;
    ToggleButton toggleButton;

    private Marker currentUserLocationMarker;
    private static final int Request_user_location_code = 99;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_location);

        if(!isNetworkAvailable()){
            Intent no_internet = new Intent(this,no_internet.class);
            startActivity(no_internet);
            CustomIntent.customType(myLocation.this,"rotateout-to-rotatein");
        }

        Paper.init(this);








        SparkButton sparkButton = findViewById(R.id.add_location);
        sparkButton.setEventListener(new SparkEventListener() {
            @Override
            public void onEvent(ImageView button, boolean buttonState) {
                openDialog();
            }

            @Override
            public void onEventAnimationEnd(ImageView button, boolean buttonState) {

            }

            @Override
            public void onEventAnimationStart(ImageView button, boolean buttonState) {

            }
        });

        // Get Previous Locations and stuff
            // Obtain the SupportMapFragment and get notified when the map is ready to be used.
            SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
            mapFragment.getMapAsync(myLocation.this);


        /*** Bottom Navigation ;) **/
        BottomNavigationView bottomNavigationView = findViewById(R.id.navigation);
        bottomNavigationView.setSelectedItemId(R.id.myLocations);

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home: //home
                        activity = new Intent(myLocation.this, Home.class);
                        startActivity(activity);
                        CustomIntent.customType(myLocation.this,"fadein-to-fadeout");
                        break;

                    case R.id.search: //unknown
                        startActivity(new Intent(myLocation.this, Search.class));
                        CustomIntent.customType(myLocation.this, "fadein-to-fadeout");
                        return true;
                    case R.id.myLocations:
                        //TODO
                        return true;

                    case R.id.self_check:
                        startActivity(new Intent(myLocation.this,Self_check.class));
                        CustomIntent.customType(myLocation.this,"fadein-to-fadeout");
                        return true;

                    case R.id.Stats:
                        startActivity(new Intent(myLocation.this,Map_graph.class));
                        CustomIntent.customType(myLocation.this,"fadein-to-fadeout");
                        return true;
                }
                return true;
            }
        });

        toggleButton = findViewById(R.id.toggleButton);
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    mMap.setMapType(mMap.MAP_TYPE_HYBRID);
                }
                else{
                    mMap.setMapType(mMap.MAP_TYPE_NORMAL);
                }
            }
        });



    } //End of Oncreate

    /****Start  of Everyting to Create the map *****/
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        //Checks if we have permission ;)
        if(checkUserLocationPermission()) {
            if (ContextCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

                buildGoogleApiClient();
                mMap.setMyLocationEnabled(true);

            }
            /***** okhttp to place covid + users ********/
            OkHttpClient client = new OkHttpClient();

            HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/JoinTablesUL.php").newBuilder();
            String url = urlBuilder.build().toString();
            final Request request = new Request.Builder()
                    .url(url)
                    .build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(@NotNull Call call, @NotNull IOException e) {
                    e.printStackTrace();
                }

                @Override
                public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                    final String responseData = response.body().string();
                    if (!response.isSuccessful()) {
                        throw new IOException("Unexpected code " + response);
                    }
                    else {
                        myLocation.this.runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    JSONArray all = new JSONArray(responseData);
                                    for (int i = 0; i < all.length(); i++) {
                                        JSONObject obj = all.getJSONObject(i);
                                        String lat = obj.getString("LOCATION_LATITUDE");
                                        String lon = obj.getString("LOCATION_LONGITUDE");
                                        LatLng coordinate = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));
                                        MarkerOptions markerOptions = new MarkerOptions()
                                                .title("COVID-19 +  user was here")
                                                .icon(BitmapDescriptorFactory.fromResource(R.drawable.coronavirus))
                                                .position(coordinate);
                                        mMap.addMarker(markerOptions);
                                    }
                                } catch (JSONException e) {
                                    e.printStackTrace();

                                }
                            }
                        });

                    }

                }
            });





            /**********************************************/
            //** Animate to curr location at Start of Map ***/
            LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            Criteria criteria = new Criteria();
            String provider = locationManager.getBestProvider(criteria, true);
            Location location = locationManager.getLastKnownLocation(provider);

            if (location != null) {
                LatLng coordinate = new LatLng(location.getLatitude(), location.getLongitude());
                MarkerOptions markerOptions = new MarkerOptions()
                        .title("Current Location") // Sets the orientation of the camera to east
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.user_location))
                        .position(coordinate);
                mMap.addMarker(markerOptions);
                CameraUpdate yourLocation = CameraUpdateFactory.newLatLngZoom(coordinate, 17);
                mMap.animateCamera(yourLocation);
            }
        }

    }

    public boolean checkUserLocationPermission(){
        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            if(ActivityCompat.shouldShowRequestPermissionRationale(this, ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, Request_user_location_code);
            }
            else{
                ActivityCompat.requestPermissions(this, new String[]{ACCESS_FINE_LOCATION}, Request_user_location_code);
            }
            return false;
        }
        return true;
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case Request_user_location_code:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                        if(googleApiClient == null){
                            buildGoogleApiClient();
                        }
                        mMap.setMyLocationEnabled(true);
                    }
                    else{
                        Toast.makeText(myLocation.this, "Permission Denied",Toast.LENGTH_LONG).show();
                    }
                    return;
                }
        }

    }



    protected synchronized void buildGoogleApiClient() { //gets us a new API client for Locations handling
        googleApiClient = new GoogleApiClient.Builder(myLocation.this)
                .addConnectionCallbacks(myLocation.this)
                .addOnConnectionFailedListener(myLocation.this).addApi(LocationServices.API)
                .build();

        googleApiClient.connect();
    }

    @Override
    public void onLocationChanged(Location location) {
        lastlocation = location;

        if(currentUserLocationMarker != null){
            currentUserLocationMarker.remove();
        }
        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());
        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("Current Location");
        markerOptions.icon(BitmapDescriptorFactory.fromResource(R.drawable.user_location));


        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(location.getLatitude(), location.getLongitude()), 13));

        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(new LatLng(location.getLatitude(), location.getLongitude()))      // Sets the center of the map to location user
                .zoom(17)                   // Sets the zoom
                .bearing(90)                // Sets the orientation of the camera to east
                .tilt(40)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

        // currentUserLocationMarker = mMap.addMarker(markerOptions);
        //    mMap.moveCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));//zoom
        //   mMap.animateCamera(CameraUpdateFactory.newLatLng(latLng));
        //send an okHTTP request to store new location for user

        //SendLocationToDatabase(location.getLatitude(),location.getLongitude());

        /***** okhttp to place covid + users ********/
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/JoinTablesUL.php").newBuilder();
        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(@NotNull Call call, @NotNull Response response) throws IOException {
                final String responseData = response.body().string();
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                }
                else {
                    myLocation.this.runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                JSONArray all = new JSONArray(responseData);
                                for (int i = 0; i < all.length(); i++) {
                                    System.out.println("Success");
                                    JSONObject obj = all.getJSONObject(i);
                                    String lat = obj.getString("LOCATION_LATITUDE");
                                    String lon = obj.getString("LOCATION_LONGITUDE");
                                    LatLng coordinate = new LatLng(Double.parseDouble(lat), Double.parseDouble(lon));
                                    MarkerOptions markerOptions = new MarkerOptions()
                                            .title("COVID-19 +  user was here")
                                            .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED))
                                            .position(coordinate);
                                    mMap.addMarker(markerOptions);
                                }
                            } catch (JSONException e) {
                                e.printStackTrace();

                            }
                        }
                    });

                }

            }
        });





        /**********************************************/

        //Doing some testing
        if(googleApiClient != null){
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, myLocation.this);
        }
    }


    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1100);
        locationRequest.setFastestInterval(1100);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this, ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, myLocation.this);
        }

    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    /****End of Everyting to Create the map *****/


    public void SendLocationToDatabase(double lat , double lon){
        OkHttpClient client = new OkHttpClient();

        HttpUrl.Builder urlBuilder = HttpUrl.parse("https://lamp.ms.wits.ac.za/home/s1828559/UploadLocation.php").newBuilder();
        urlBuilder.addQueryParameter("USER_ID", Paper.book().read(utilities.id).toString());
        urlBuilder.addQueryParameter("LOCATION_LATITUDE", Double.toString(lat));
        urlBuilder.addQueryParameter("LOCATION_LONGITUDE", Double.toString(lon));


        String url = urlBuilder.build().toString();
        final Request request = new Request.Builder()
                .url(url)
                .build();

        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(@NotNull Call call, @NotNull IOException e) {
                e.printStackTrace();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if (!response.isSuccessful()) {
                    throw new IOException("Unexpected code " + response);
                } else {
                    server_response = response.body().string(); // actual server response
                    System.out.println("Response " + server_response);
                    success = server_response.equals("Success"); //boolean
                }
            }
        });

    }

   // *** Menu Stuff *** //
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    public void openDialog() {

            LocationManager locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            Criteria criteria = new Criteria();
            String provider = locationManager.getBestProvider(criteria, true);
            assert provider != null;
             @SuppressLint("MissingPermission") Location location = locationManager.getLastKnownLocation(provider);
            assert location != null;
            SendLocationToDatabase(location.getLatitude(),location.getLongitude());

            //before inflating the custom alert dialog layout, we will get the current activity viewgroup
            ViewGroup viewGroup = findViewById(android.R.id.content);
            //then we will inflate the custom alert dialog xml that we created
            View dialogView = LayoutInflater.from(this).inflate(R.layout.pop_up, viewGroup, false);

            //Now we need an AlertDialog.Builder object
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            //setting the view of the builder to our custom view that we already inflated
            builder.setView(dialogView);

            //finally creating the alert dialog and displaying it
            final AlertDialog alertDialog = builder.create();

            Button dismiss = dialogView.findViewById(R.id.dismiss);
            Button prev = dialogView.findViewById(R.id.prev);

            if(success){
                RelativeLayout relativeLayout = dialogView.findViewById(R.id.color);
                relativeLayout.setBackground(getResources().getDrawable(R.drawable.color_green));
                    TextView text = dialogView.findViewById(R.id.response);
                    text.setText(R.string.location_success);
                    text.setTextColor(getResources().getColor(R.color.green));
            }
            else{
                RelativeLayout relativeLayout = dialogView.findViewById(R.id.color);
                relativeLayout.setBackground(getResources().getDrawable(R.drawable.color_important));
                TextView text = dialogView.findViewById(R.id.response);
                text.setText(R.string.error);
                text.setTextColor(Color.RED);
            }
            dismiss.setOnClickListener(new View.OnClickListener() {
                 @Override
                public void onClick(View v) {
                    alertDialog.dismiss();
                }
            });

            prev.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent start = new Intent(myLocation.this,Previous_locations.class);
                    startActivity(start);
                }
            });

            alertDialog.show();

    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

    public void formatLocation(String json,Set<LatLng> s){
        try {
            JSONArray all = new JSONArray(json);
            for(int i = 0;i < all.length();i++){
                JSONObject obj = all.getJSONObject(i);
                String lat = obj.getString("LOCATION_LATITUDE");
                String lon = obj.getString("LOCATION_LONGITUDE");
                double a_lat = Double.parseDouble(lat);
                double a_lon = Double.parseDouble(lon);
                LatLng l = new LatLng(a_lat,a_lon);
                if (s != null) {
                    s.add(l);
                }
            }
        }
        catch (JSONException e) {
            e.printStackTrace();
        }
    }

    //sync okhttp




}
