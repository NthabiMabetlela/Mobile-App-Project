package com.example.norona_tracking;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import io.paperdb.Paper;
import maes.tech.intentanim.CustomIntent;

public class Map_summary extends AppCompatActivity {
    private ProgressBar progressBar;
    static TextView Deaths,Infected,Recovered;
    BottomNavigationView Top_nav,stats_navbar;
    static TextView recover_sa,dead_sa,infected_sa,url;
    ArrayList<String> vals = new ArrayList<>();
    ArrayList<String> vals_sa = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_map_summary);

        ActionBar toolbar = getSupportActionBar();
        toolbar.setTitle("Statistics");
        toolbar.setIcon(R.mipmap.ic_launcher);



        /*** Setting up the Nav Bar Bottom ****/
        stats_navbar = findViewById(R.id.navigation);
        stats_navbar.setSelectedItemId(R.id.Stats);

        stats_navbar.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                Intent activity;
                switch (item.getItemId()) {
                    case R.id.home:
                        activity = new Intent(Map_summary.this, Home.class);
                        startActivity(activity);
                        CustomIntent.customType(Map_summary.this,"fadein-to-fadeout");
                        break;
                    case R.id.search:
                        startActivity(new Intent(Map_summary.this, Search.class));
                        CustomIntent.customType(Map_summary.this, "fadein-to-fadeout");
                        return true;
                    case R.id.myLocations:
                        //TODO
                        startActivity(new Intent(Map_summary.this,myLocation.class));
                        CustomIntent.customType(Map_summary.this,"fadein-to-fadeout");
                        return true;
                    case R.id.self_check:
                        //TODO:
                        startActivity(new Intent(Map_summary.this,Self_check.class));
                        CustomIntent.customType(Map_summary.this,"fadein-to-fadeout");
                        return true;
                    case R.id.Stats:
                        return true;

                }
                return true;
            }
        });
        if(!isNetworkAvailable()){
            Intent no_internet = new Intent(this,no_internet.class);
            startActivity(no_internet);
            CustomIntent.customType(this,"rotateout-to-rotatein");
        }
        else{
            new MyTask().execute(); //get our stats need internet
        }


        /*** Map Nav Creation ***/
        Top_nav = (BottomNavigationView)findViewById(R.id.bottomNavigationView);
        Top_nav.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){

                    case R.id.nav_stats:
                        break;
                    case R.id.nav_map:
                        Intent map = new Intent(Map_summary.this,Map_graph.class);
                        startActivity(map);
                        CustomIntent.customType(Map_summary.this,"right-to-left");
                        break;

                }
                return true;
            }
        });

        url = findViewById(R.id.link);
        url.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url = "https://www.worldometers.info/coronavirus/";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
            }
        });


    } //End of Oncreate



    private class MyTask extends AsyncTask<Void, Void, Void> {
        String result;
        @Override
        protected Void doInBackground(Void... voids) {
            if(isNetworkAvailable()) {
                try {
                    Document doc = Jsoup.connect("https://www.worldometers.info/coronavirus/").get();
                    Document sa = Jsoup.connect("https://www.worldometers.info/coronavirus/country/south-africa/").get();
                    Elements temp = doc.select("div.maincounter-number");
                    Elements sa_stats = sa.select("div.maincounter-number");

                    for (Element f : temp) {
                        vals.add(f.getElementsByTag("span").first().text());
                    }

                    for (Element f : sa_stats) {
                        vals_sa.add(f.getElementsByTag("span").first().text());
                    }

                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }
        @Override
        protected void onPostExecute(Void aVoid) {
            Deaths = (TextView) findViewById(R.id.deaths);
            Infected = (TextView)findViewById(R.id.infections);
            Recovered = (TextView)findViewById(R.id.recovered);
            dead_sa = (TextView)findViewById(R.id.sa_deaths);
            recover_sa = (TextView)findViewById(R.id.sa_recovered);
            infected_sa = (TextView)findViewById(R.id.sa_infections);
    if(isNetworkAvailable()) {
        Deaths.setText(vals.get(1));
        dead_sa.setText((vals_sa.get(1)));
        Infected.setText(vals.get(0));
        infected_sa.setText(vals_sa.get(0));
        Recovered.setText(vals.get(2));
        recover_sa.setText(vals_sa.get(2));
    }
    else{
        Deaths.setText("No Internet Connection");
        dead_sa.setText("No Internet Connection");
        Infected.setText("No Internet Connection");
        infected_sa.setText("No Internet Connection");
        Recovered.setText(R.string.no_net);
        recover_sa.setText("No Internet Connection");
    }
        super.onPostExecute(aVoid);

        }
    }
    // MENU STUFF
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.top_nav,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.profile:
                Intent profile = new Intent(this, Profile.class);
                startActivity(profile);
                return true;
            case R.id.sign_out:
                Paper.book().destroy();
                Intent out = new Intent(this, splash_home.class);
                startActivity(out);
                return true;
            case R.id.contact:
                Toast.makeText(this, "norona2020@gmail.com", Toast.LENGTH_LONG).show();
                return true;

            case R.id.about:
                Toast.makeText(this, "NORONA by 2 Cups O' Java", Toast.LENGTH_LONG).show();
                return true;
        }
        return false;
    }

    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }

}
