package com.example.norona_tracking;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DataBaseHelper extends SQLiteOpenHelper {

    private static String DB_NAME = "Mask_On.db";
    private static String TABLE_NAME = "USERS";
    private static String COL_0= "USER_ID";
    private static String COL_1= "NAME";
    private static String COL_2 = "EMAIL";
    private static String COL_3 = "PASSWORD";

    public DataBaseHelper(@Nullable Context context) {
        super(context, DB_NAME, null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE USERS(USER_ID INTEGER PRIMARY KEY AUTOINCREMENT ,NAME TEXT , EMAIL TEXT , PASSWORD TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
    }

    public SQLiteDatabase getDB(){
        return getWritableDatabase();
    }
    public long addUser(String username , String mail , String password){

        SQLiteDatabase database = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("NAME",username);
        contentValues.put("EMAIL",mail);
        contentValues.put("PASSWORD",password);
        long res = database.insert(TABLE_NAME,null, contentValues);
        database.close();
        return res;
    }



    public  final boolean checkUser(String Username, String email, String password){ //Check if user already exists

        String[] columns = {COL_0};
        SQLiteDatabase db = this.getWritableDatabase();
        String selection = COL_1 + "=?" + " AND " + COL_2 + "=?" + " AND " + COL_3 + "=?";
        String[] selectionargs = {Username,email,password};
        Cursor c = db.query(TABLE_NAME, columns, selection, selectionargs, null, null, null);
        int count = c.getCount();
        c.close();
        db.close();
        if(count > 0){
            return true;
        }
        else{
            return false;
        }
    }

}