package com.example.norona_tracking;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.widget.TextView;

import static android.view.Gravity.CENTER;

public class tip extends androidx.appcompat.widget.AppCompatTextView {
    public tip(Context context) {
        super(context);
    }

    public TextView add(String text, Drawable d , Drawable icon){
        TextView t = new TextView(getContext());
        t.setPadding(10, 15, 15, 15);
        t.setText(text);
        t.setTextSize(16);
        t.setBackground(d);
        t.setCompoundDrawablesWithIntrinsicBounds(icon,null,null,null);
        t.setTextColor(Color.WHITE);
        t.setGravity(CENTER);
        return t;
    }
}
