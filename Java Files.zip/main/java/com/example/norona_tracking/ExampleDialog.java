package com.example.norona_tracking;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatDialogFragment;

public class ExampleDialog extends AppCompatDialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setTitle("Add my Location")
                .setIcon(getResources().getDrawable(R.drawable.ic_outline_location_on_24))
                .setMessage("Set it to some text")
                .setPositiveButton("DISMISS", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //Dismisses the view
                    }
                })
                .setNegativeButton("PREVIOUS LOCATIONS", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent prev = new Intent(getActivity(),Previous_locations.class);
                        startActivity(prev);
                    }
                });

        return builder.create();
    }
}
